#include <iostream>
#include <cstdlib>
#include "Heap.h"
using namespace std;
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : CPP code to implement Dijkstra's shortest path algorithm using adjacency list.
*    Question : Lab11 Q1
-------------------------------------------------------------------------------------------------*/

/*******HEAP FUNCTIONS START HERE*******/
/*-------------------------------------------------------------------------------------------------
*    Function Name : funSwap
*    Args : 2 adresses of HeapNode pointers.
*    Return Type: None(swaps 2 HeapNode Pointers)
-------------------------------------------------------------------------------------------------*/
void MinHeap::funSwap(struct HeapNode** x, struct HeapNode** y) //Function for swapping the required 2 values using a temporary variable
{
    struct HeapNode* temp = *x; //temp variable to carry out swapping
    *x = *y;
    *y = temp;    
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : empty
*    Args : None
*    Return Type: int(1 if heap is empty)
-------------------------------------------------------------------------------------------------*/
int MinHeap::empty()
{
    if(last==-1)
        return 1;

    return 0;
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : decreaseKey
*    Args : NodeType, WeightType
*    Return Type: None(Decreases the distance of a vertex)
-------------------------------------------------------------------------------------------------*/
void MinHeap::decreaseKey(NodeType tempNode, WeightType tempLen) // WeightType can be used to denote the current distance from source
{
    int tempPos=0, refNode; //ints for facilitating reodering
    for(int i=0; i<last+1; i++) //for loop to find required node in heap
    {
        if(heap[i]->node == tempNode)   //if conditional to see if node is reached or not
        {
            tempPos = i;
            break;
        }
    }

    heap[tempPos]->minDistance=tempLen; //decreasing the key

    while(tempPos) //while loop to rearrange the heap after value updating
    {
        refNode = (tempPos-1)/2; //getting index of parent node
        if(heap[tempPos]->minDistance < heap[refNode]->minDistance) //if condtion to compare keys
        {
            funSwap(&heap[tempPos], &heap[refNode]);
            tempPos = refNode; //updating index for while
        }

        else //breaking if heap is already ordered
            break;
    }
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : deleteRoot
*    Args : None
*    Return Type: struct HeapNode*
-------------------------------------------------------------------------------------------------*/
struct HeapNode* MinHeap::deleteRoot()
{
    int tempPos=0, refNode;  //two position checkers to rearrange heap after deletion
    struct HeapNode* tempElem = heap[0]; //obtaining root node to return after its deletion
    if(!last) //if only one element exists
    {
        last = -1;  //updating last 
        return tempElem; //returning tempElem
    }

    heap[tempPos] = heap[last]; //updating root node with last element.
    last-=1;
    while(2*tempPos < last) //while loop to rearrange heap
    {
        refNode = 2*tempPos +1; //getting child node position
        if(refNode==last)   //if we approach the last element of the heap
        {
            if(heap[tempPos]->minDistance >heap[refNode]->minDistance) //comparing elements to check if need to be exchnged or not
            {
                funSwap(&heap[refNode], &heap[tempPos]); //swapping elements
                tempPos = last; //updating last tempPos position
            }
            break; //breaking the loop
        }

        else
        {
            if(heap[refNode]->minDistance>heap[refNode+1]->minDistance) //comparing child nodes to get larger child node
            {
                refNode++;  //updating childnode pointer
            }

            if(heap[tempPos]->minDistance > heap[refNode]->minDistance) //comparing elements to check if need to be exchnged or not
            {
                funSwap(&heap[refNode], &heap[tempPos]); //swapping elements
                tempPos = refNode; //updating last tempPos position
            }

            else
                break; //breaking if no changes are there
        }
    }
    return tempElem;
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : insert
*    Args : NodeType, WeightType
*    Return Type: None(inserts nodes)
-------------------------------------------------------------------------------------------------*/
void MinHeap::insert(NodeType node, WeightType weight)
{
    last++; //incrimenting last variable
    struct HeapNode* tempNode = (HeapNode*)malloc(sizeof(struct HeapNode));
    int tempPos=last, refNode; //values for faciltaing exchanges
    tempNode->node = node;  //assignment of vals
    tempNode->minDistance = weight;  //assignment of vals
    heap[last] = tempNode;  //assignment of vals

    while(tempPos>0)
    {
        refNode = (tempPos-1)/2; //getting index of parent
        if(heap[tempPos]->minDistance < heap[refNode]->minDistance) //comparing with parent
        {
            funSwap(&heap[tempPos], &heap[refNode]); //swapping to correect the heap
            tempPos = refNode; //updating new index for inserted node to move further
        }

        else 
            break; //breaking in heap is already ok
    }
}
/*******HEAP FUNCTIONS END HERE*******/