#pragma once
#include <iostream>
#include <cstdlib>
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : CPP Header code to implement Dijkstra's shortest path algorithm using adjacency list.
*    Question : Lab11 Q1
-------------------------------------------------------------------------------------------------*/
typedef int NodeType;
typedef int WeightType;
struct HeapNode //struct for finding shortest path using minHeap
{
    NodeType node; //node point 
    WeightType minDistance; //minimum distance from source
};

class MinHeap{
    
        struct HeapNode **heap;  // Heap Node should store a graph node and distance from the source                            
        /** Other Variables As Required **/
        int last, v;
    public:        
        void decreaseKey(NodeType, WeightType); // WeightType can be used to denote the current distance from source
        struct HeapNode* deleteRoot();
        void insert(NodeType, WeightType);
        /** Other Functions As Required **/
        int empty();                   // returns 1 if Heap is empty
        void funSwap( struct HeapNode**, struct HeapNode**);
        MinHeap(int v)  //HeapMAXSize as argument passes for the constructor
        {
            this->v = v;
            heap = (struct HeapNode**)malloc(v*sizeof(struct HeapNode*)); //creating a double pointer for MinHeap
            last = -1;
        }
};
