#include <iostream>
#include <cstdlib>
#include <climits>
#include "Graph.h"
#include "Heap.h"
using namespace std;
#define INFI INT_MAX
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : CPP code to implement Dijkstra's shortest path algorithm using adjacency list.
*    Question : Lab11 Q1
-------------------------------------------------------------------------------------------------*/

/*******GRAPH FUNCTIONS START HERE*******/
/*-------------------------------------------------------------------------------------------------
*    Function Name : addEdge
*    Args : NodeType, NodeType, WeightType
*    Return Type: None(creates an edge)
-------------------------------------------------------------------------------------------------*/
void Graph::addEdge(NodeType start, NodeType end, WeightType weight)
{
    ListNode* tempNode1 = (ListNode*)malloc(sizeof(ListNode)); //creating a new list node's memory space
    ListNode* tempNode2 = (ListNode*)malloc(sizeof(ListNode)); //creating a new list node's memory space

    tempNode1->pointDest = end; //destination point
    tempNode1->weight = weight; //weight of the edge
    tempNode1->link = NULL; //initialising the link with null pointer
    addNode(start, tempNode1);

    if(start!=end)
    {
        tempNode2->pointDest = start; //destination point
        tempNode2->weight = weight; //weight of the edge
        tempNode2->link = NULL; //initialising the link with null pointer
        addNode(end, tempNode2);
    }
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : addNode
*    Args : NodeType, ListNode pointer
*    Return Type: None(creates a node in the adjacent list)
-------------------------------------------------------------------------------------------------*/
void Graph::addNode(NodeType start, ListNode* tempNode)
{
    ListNode* tempRoot = adjList[start]; //temporary root or the instantaneous source vertex

    if(tempRoot==NULL) //inserting into the curresponding adjacency root(if to check 1st elem or not)
    {
        adjList[start] = tempNode; //inserting element into root position
    }

    else
    {
        while(tempRoot->link) //finding the nodepointer of the last node
        {
            tempRoot = tempRoot->link; //updating list pointer to move forward
        }

        tempRoot->link = tempNode; //inserting element into List
    }
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : minPathFinder
*    Args : None
*    Return Type: None(Prints weight of smallest path of all nodes from source)
-------------------------------------------------------------------------------------------------*/
void Graph::minPathFinder()
{
    MinHeap A(v); //getting a new min heap
    int pathLen[v];    //getting an integer arrays
    for(int i=0; i<v; i++) //for loop for all  initialisations
    {
        A.insert(i, INFI);
        pathLen[i] = INFI;
    }

    pathLen[0] = 0;
    A.decreaseKey(0, 0); //initialising source value to zero

    while(!A.empty()) //while list isnt empty
    {
        struct HeapNode* tempNode = A.deleteRoot();
        int tempInd = tempNode->node; //storing the obtained node Index.
        ListNode* tempListNode = adjList[tempInd]; //obtaining root pointer of adjacency list of vertex with index tempInd

        while(tempListNode) //while end of adjacency list is not reached
        {
            int tempNum = tempListNode->pointDest;  //obtaining the index of adjacent node
            if(pathLen[tempInd]!=INFI && pathLen[tempInd]+tempListNode->weight<pathLen[tempNum])    //if condition to check if minimum path length is reached or not.
            {
                pathLen[tempNum] = pathLen[tempInd] + tempListNode->weight; //updating minimum path length
                A.decreaseKey(tempNum, pathLen[tempNum]); //updating the new key
            }

            tempListNode = tempListNode->link; //proceding to next adjacent node
        }
    }

    for(int i=0; i<v; i++) //for loop for printing in the required format
    {
        cout << i << " " << pathLen[i] << endl;
    }
}
/*******GRAPH FUNCTIONS END HERE*******/