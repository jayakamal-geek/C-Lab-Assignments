#pragma once
#include <iostream>
#include <cstdlib>
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : CPP Header code to implement Dijkstra's shortest path algorithm using adjacency list.
*    Question : Lab11 Q1
-------------------------------------------------------------------------------------------------*/

typedef int NodeType;
typedef int WeightType;
typedef struct ListNode //struct for representing adjacent list node
{
    NodeType pointDest; //Destination of edge
    WeightType weight; //weight of the edge
    struct ListNode* link; //connection to next link
}AdjListNode; //alias for the struct

class Graph{
     int v;         // no of vertices in a graph
     /** Other Variables As Required **/
     ListNode** adjList;
    
     public:
        void addEdge(NodeType, NodeType, WeightType);
        /** Other Functions As Required **/
        void addNode(NodeType, ListNode*);
        void minPathFinder(); //function uses dijkstra algorithm to find the minimum path from source to other nodes
        Graph(int vertices) //class constructor of class graph
        {
            this->v = vertices; //initialising number of vertices of the class instance
            this->adjList = (ListNode**)calloc(vertices, sizeof(ListNode*)); //creating a double pointer for adjacency list
        }
 };