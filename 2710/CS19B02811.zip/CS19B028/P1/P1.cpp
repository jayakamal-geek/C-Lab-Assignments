#include <iostream>
using namespace std;
#include "Graph.h"
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : CPP code to implement Dijkstra's shortest path algorithm using adjacency list.
*    Question : Lab11 Q1
-------------------------------------------------------------------------------------------------*/


/*-------------------------------------------------------------------------------------------------
*    Function Name : main
*    Args : None
*    Return Type: int(for exiting the program)
-------------------------------------------------------------------------------------------------*/
int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */
    int numVertices, numEdges;  //variables for storing number of vertices and number of edges
    NodeType start, dest; //temp variables to store taken in inputs(end points).
    WeightType weight; //temp variable to store taken in input(weight of an edge).

    cin >> numVertices >> numEdges; //taking inputs of number of edges and number of vertices.
    Graph A(numVertices); //initialisng a graph using constructor.

    for(int i=0; i<numEdges; i++)   //for loop to take inputs of endpoints and weights of all edges
    {
        cin >> start >> dest >> weight; //taking inputs of endpoints and weights of an edge.
        A.addEdge(start, dest, weight); //Adding an edge to the graph.
    }

    A.minPathFinder();

    return 0; //return statement of main to end the program
}