#include<iostream>
#include "listADT_arr.h"
using std::cout;
using std::endl;

void Print (ElementType x) {
  cout << x.coefficient<< " " << x.degree<< " ";
}
 

void List::makeNull() {
  list = new CellNode[10000]; 
  lastNode = 0;
}
void List::insert(ElementType val, Position p) {
  int i;
  for (i = lastNode+1; i > p; i--)
    list[i] = list[i-1];
  list[p].value = val;
  lastNode++;
}
void List::printList() {
  Position p;
  p = 1;
  if(lastNode == 0){
    cout<<"EMPTY LIST\n";
    return ;
  }
  while (p <= lastNode) {
    Print (list[p].value);
    p++;
  }
  cout << "\n";
}

Position List::end() {
  Position p;
  p = lastNode + 1;
  return(p);
}

Position List::first() {
  return(1);
}
Position List::next(Position p) {
  return (p+1);
}
ElementType List::retrieveValue(Position p) {
  return (list[p].value);
}