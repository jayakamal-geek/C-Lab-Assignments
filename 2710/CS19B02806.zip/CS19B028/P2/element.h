#pragma once
#include<iostream>

typedef struct ElementType {
  int coefficient;
  int degree;
} PolyNode;
