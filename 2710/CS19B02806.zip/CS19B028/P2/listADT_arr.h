#pragma once
#include<iostream>
#include "element.h"

/*-------------------------------------------------------------------------------------------------
*	Author : Maddula Jaya Kamal(cs19b028)
*	Code : Header file for functions of ADT-list(array type).
-------------------------------------------------------------------------------------------------*/

typedef int Position;
typedef struct CellType {
  ElementType value;
  Position next;
} CellNode;

class List {
    public:
        void insert(ElementType val,  Position p);  //method to insert new element into the list
        void delItem(Position p);
        void makeNull();    //method for intitializing the list and getting it ready for use.
        void printList();   //method for printing the list
        ElementType retrieveValue(Position p);  //Method to obtain the required list
        Position end(); //method to obtain pointer to the end of the list
        Position first();   //method to obtain pointer to the start of the list
        Position next(Position p);  //giving the pointer to next element of a given pointer

    private:
        Position lastNode;
        CellNode*  list;
};

