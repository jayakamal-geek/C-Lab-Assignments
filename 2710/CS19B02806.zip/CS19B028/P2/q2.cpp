#include <iostream>
#include "listADT_arr.h"
using std::cin;

/*-------------------------------------------------------------------------------------------------
*	Author : Maddula Jaya Kamal(cs19b028)
*	Code : Cpp-code to add 2 lists of pollynomials.
*	Question : Lab06 Q2
-------------------------------------------------------------------------------------------------*/


/*-------------------------------------------------------------------------------------------------
*	Function Name : PolynomialAdd
*	Args : 2 polynomial lists
*	Return Type: list(sum of 2 lists)
-------------------------------------------------------------------------------------------------*/
List PolynomialAdd(List A, List B) //function for adding 2 polynomials
{
	List C; //sum list
    C.makeNull(); //initialising list
    Position startA=A.first(), startB=B.first(), endA=A.end(), endB=B.end(), ptrC = C.first(); //initialising all necessary variables
    ElementType tempTerm1, tempTerm2, tempTerm; //temporary structs for storing values

    while(startA!=endA && startB!=endB)//while the pointing vars dont reach the end.
    {
        tempTerm1=A.retrieveValue(startA);
        tempTerm2=B.retrieveValue(startB);

        if(tempTerm1.degree == tempTerm2.degree) //computing operation between equal degrees
        {
            tempTerm.coefficient = tempTerm1.coefficient + tempTerm2.coefficient;
            tempTerm.degree = tempTerm1.degree;
            startA = A.next(startA);
            startB = B.next(startB);
        }

        else if(tempTerm1.degree > tempTerm2.degree) //incrimenting to make equal degrees
        {
            tempTerm = tempTerm1;
            startA = A.next(startA);
        }

        else //incrimenting to make equal degrees
        {
            tempTerm = tempTerm2;
            startB = B.next(startB);   
        }

        if(tempTerm.coefficient)//inserting non zero terms into result
        {
            C.insert(tempTerm, ptrC);
            ptrC = C.next(ptrC);
        }
    }

    while(startA!=endA)//addiing left over terms
    {
        C.insert(A.retrieveValue(startA), ptrC);
        startA = A.next(startA);
        ptrC = C.next(ptrC);
    }

    while(startB!=endB)//addding left over terms
    {
        C.insert(B.retrieveValue(startB), ptrC);
        startA = B.next(startB);
        ptrC = C.next(ptrC);
    }

  	return C;//returning result
}

/*-------------------------------------------------------------------------------------------------
*	Function Name : PolynomialSubtract
*	Args : 2 polynomial lists
*	Return Type: list(difference of 2 lists)
-------------------------------------------------------------------------------------------------*/

List PolynomialSubtract(List A, List B) //function for adding 2 polynomials
{
	List C; //sum list
    C.makeNull(); //initialising list
    Position startA=A.first(), startB=B.first(), endA=A.end(), endB=B.end(), ptrC = C.first(); //initialising all necessary variables
    ElementType tempTerm1, tempTerm2, tempTerm; //temporary structs for storing values

    while(startA!=endA && startB!=endB)//while the pointing vars dont reach the end.
    {
        tempTerm1=A.retrieveValue(startA);
        tempTerm2=B.retrieveValue(startB);

        if(tempTerm1.degree == tempTerm2.degree) //computing operation between equal degrees
        {
            tempTerm.coefficient = tempTerm1.coefficient - tempTerm2.coefficient;
            tempTerm.degree = tempTerm1.degree;
            startA = A.next(startA);
            startB = B.next(startB);
        }

        else if(tempTerm1.degree > tempTerm2.degree) //incrimenting to make equal degrees
        {
            tempTerm = tempTerm1;
            startA = A.next(startA);
        }

        else //incrimenting to make equal degrees
        {
            tempTerm.coefficient = -1 * tempTerm2.coefficient;
            tempTerm.degree = tempTerm2.degree;
            startB = B.next(startB);   
        }

        if(tempTerm.coefficient) //inserting new element in to C.
        {
            C.insert(tempTerm, ptrC);
            ptrC = C.next(ptrC);
        }
    }

    while(startA!=endA)//addding left over terms
    {
        C.insert(A.retrieveValue(startA), ptrC);
        startA = A.next(startA);
        ptrC = C.next(ptrC);
    }

    while(startB!=endB)//addding left over terms
    {
        tempTerm2 = B.retrieveValue(startB);
        tempTerm.coefficient = -1 * tempTerm2.coefficient;
        tempTerm.degree = tempTerm2.degree;
        C.insert(tempTerm, ptrC);
        ptrC = C.next(ptrC);
        startB = B.next(startB);
    }

  	return C; //returning result
}

/*-------------------------------------------------------------------------------------------------
*	Function Name : main
*	Args : None
*	Return Type: int(To Exit)
-------------------------------------------------------------------------------------------------*/
int main() {
     
  	List A, B, C, D;
  	/* Read two polynomial using the given ADT and perform the Addition and Subtraction */
    A.makeNull(); B.makeNull(); C.makeNull(); D.makeNull();

    int listSize1, listSize2;
    cin >> listSize1 >> listSize2;

    for(int i=0; i<listSize1; i++)
    {
        ElementType tempTerm;

        cin >> tempTerm.coefficient>> tempTerm.degree; 
        A.insert(tempTerm, i+1);
    }

    for(int i=0; i<listSize2; i++)
    {
        ElementType tempTerm;

        cin >> tempTerm.coefficient>> tempTerm.degree; 
        B.insert(tempTerm, i+1);
    }
  	
  	C = (List) PolynomialAdd (A, B);
    C.printList();
  	D = (List) PolynomialSubtract (A, B);
    D.printList();

    cin.ignore();
    cin.get();
    return 0;
}