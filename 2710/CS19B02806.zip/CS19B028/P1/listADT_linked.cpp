#include<iostream>
#include "element.h"
#include "listADT_linked.h" //user defined header file
using std::cout;
using std::endl;

void List::makeNull() 
{
    listHead = new CellNode;
    listHead->next = NULL;
}

void List::insert(ElementType val,  Position p) {
  Position temp;
  temp = p->next;
  p->next = new CellType;
  p->next->next  = temp;
  p->next->value = val;
  
}

ElementType List::retrieveValue(Position p) {
  return(p->next->value);  
}

void List::printList() 
{
    Position p;
    p = listHead->next;
    
    if(p == NULL)
        cout<<"EMPTY LIST\n";
    else
    {
        while (p != NULL)
        {
            cout<<p->value.coefficient<<" "<<p->value.degree<<" ";
            p = p->next;
        }
        cout << endl;
    }
    
 }

Position List::end() 
{
    Position p;
    p = listHead;
    while (p->next != NULL)
        p = p->next;
    return(p);
}

Position List::first() 
{
    return(listHead);
}

Position List::next(Position p) 
{
    return (p->next);
}
