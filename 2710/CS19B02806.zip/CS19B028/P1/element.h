#pragma once
#include<iostream>

typedef struct ElementType {
  int coefficient;
  int degree;
} PolyNode;


typedef struct CellType* Position;

typedef struct CellType 
{
    ElementType value;
    Position next;
} CellNode;