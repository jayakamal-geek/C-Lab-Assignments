#include <iostream>
#include <string.h>
#include <stdio.h>
#include <cstdlib>
#include "Stack.h"
using namespace std;
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : Cpp-code of Stack functions.
*    Question : Lab07 Q2
-------------------------------------------------------------------------------------------------*/

/* begin{Implementation of the class stack} */

ElemType stack::Top() {

  if (tos < STACK_SIZE)
    return (stackArray[tos]);
  else
    return(0);
  }

int stack::Empty() {

  if (tos >= STACK_SIZE)
	 return 1;
  else
	 return 0;
}

void stack::Push(ElemType x) {

  tos--;
  stackArray[tos] = x;
}

ElemType stack::Pop() {

  ElemType tmp;

  if (tos >= STACK_SIZE) 
    return (-1); 
  else {
    tmp = stackArray[tos];
    tos++;
    return (tmp);
  }
}

void stack::MakeNull() {

  tos = STACK_SIZE;

}
/* end {Implementation of stack} */