#include <iostream>
#include <string.h>
#include <stdio.h>
#include <cstdlib>
#include "Stack.h"
/*  The class stack defines an ADT stack. 
    See Ref. Aho, Hopcroft and Ullmann : Data Structures and Algorithms,
    Addison Wesley, 1978. */

/* begin {Definition of class stack} */

/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : Cpp-code to evaluate a postfix expression.
*    Question : Lab07 Q2
-------------------------------------------------------------------------------------------------*/
using namespace std;

/*-------------------------------------------------------------------------------------------------
*    Function Name : EvaluatePostFix
*    Args : Double charector pointer and an integer(number of individual arrays in 2D-array)
*    Return Type: int(result after evaluating the post-fix expression)
-------------------------------------------------------------------------------------------------*/

int EvaluatePostFix(char **postFixExpr, int exprLength) {
    int result=0; // integer variable to store result of each computation.
    int tempNum;    //tempoary variable to store int after converting string input to integer.
    stack A;    //A stack to store the integers and obtaining them when an operator is obtained.
    A.MakeNull();   //initialising our stack.

    for(int i=0;i<exprLength;i++)   //for loop to traverse across rows in our 2D arrays.
    {
        if(postFixExpr[i][0]>48)    //if an integer is detected
        {
            tempNum = atoi(postFixExpr[i]); //c++ inbuilt function to conver string to int.
            A.Push(tempNum);    //pushing the obtained value to the top of the stack
        }

        else    //else if an operator is found
        {
            int num1 = A.Pop(); //obtaining the top value on the stack and removing it from stack.
            int num2 = A.Pop(); //obtaining the top value on the stack and removing it from stack after removing the previous value.
            char tempChar = postFixExpr[i][0];  //obtaining the operator from the array

            switch(tempChar)    //switch to decide which case to perform base on operator
            {
                case '+':   result = num1+num2; //adding if the operator was +
                            A.Push(result);
                            break;

                case '-':   result = num2-num1; //subtracting if the operator is - 
                            A.Push(result);
                            break;

                case '/':   result = num2/num1; //dividing if the operator was /
                            A.Push(result);
                            break;

                case '*':   result = num1*num2; //multiplying if the operator was *
                            A.Push(result);
                            break;
            }
        }
    }
    
    result = A.Pop();   //obtaining thr only value thats present in stack(the final result)
    return result;  //returning the result
  }

/*-------------------------------------------------------------------------------------------------
*    Function Name : main
*    Args : None
*    Return Type: int(To Exit)
-------------------------------------------------------------------------------------------------*/

int main() {
  int  n;
  /* Read the input postfix expression */
  cin >> n;
  char **postFixExpr = (char**)malloc(n*sizeof(char*)); //allocating the number of arrays required to store operators and operands.

  for(int i=0; i<n; i++)
  {
      postFixExpr[i] = (char*)malloc(6*sizeof(char));   //allocating the 6 number of storage spaces as 100000 has 6 chars and it is the max value. 
      cin >> postFixExpr[i];    //taking in the inputs
  }

  for(int i=0; i<n; i++)    //for loop to print the input expression
  {
      cout << postFixExpr[i] << " ";    
  }
  cout << endl;

  int value = (int) EvaluatePostFix(postFixExpr, n);    //computing the result of the expression.
  std::cout << "The Result is :" << value << std::endl; //printing the result of the expression.

  return 0; //return value of main.
}