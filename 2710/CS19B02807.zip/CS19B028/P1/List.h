#pragma once
#include <iostream>
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : Cpp-code header file for declarations and datatype specifications
*    Question : Lab07 Q1
-------------------------------------------------------------------------------------------------*/

typedef int elementType;
typedef int Position;

class List {
public:
  void insert(elementType x, Position p);
  void delItem(Position p);
  void makeNull();
  void printList();
  Position end();
  Position first();
  Position next(Position p);
  elementType retrieve(Position p);
private:
  Position lastNode;
  elementType*  list;
};