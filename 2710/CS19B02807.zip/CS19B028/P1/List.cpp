#include <iostream>
#include <bits/stdc++.h>
#include "List.h"

/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : Cpp-code Functions of a list.
*    Question : Lab07 Q1
-------------------------------------------------------------------------------------------------*/

using namespace std;

void List::makeNull() {
  list = new elementType[100000]; 
  lastNode = 0;
}
void List::insert(elementType x, Position p) {
  int i;
  for (i = lastNode+1; i > p; i--)
    list[i] = list[i-1];
  list[p] = x;
  lastNode++;
}
void List::printList() {
  Position p;
  p = 1;
  
  while (p <= lastNode) {
    cout << list[p] << " ";
    p++;
  }
 }
Position List::end() {
  Position p;
  p = lastNode + 1;
  return(p);
}
void List::delItem(Position p) {
  int i;
  for (i = p; i < lastNode; i++)
    list[i] = list[i+1];
  lastNode = lastNode - 1;
}
Position List::first() {
  return(1);
}
Position List::next(Position p) {
  return (p+1);
}

elementType List::retrieve (Position p) {
  return (list[p]);
}

