#include <iostream>
#include <cstdlib>
#include "List.h"
using namespace std;

int QuickPos(int*, int, int); //user defined function to obtain index of pivot during quick sort
void QuickSort(int*, int, int); //user defined function to sort an array
void FunSwap(int* , int* ); //user defined function to swap ints
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : Cpp-code to find union and intersections of 2 sets using ADTs.
*    Question : Lab07 Q1
-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------
*    Function Name : Search
*    Args : list and elementType
*    Return Type: bool(element is present in the given list or not)
-------------------------------------------------------------------------------------------------*/

bool Search(elementType temp, List A)
{
    Position endPosA = A.end(), ptrPos=A.first();  //last pos of A
    while(ptrPos!=endPosA)    //for loop to traverse across A
    {
        if(temp==A.retrieve(ptrPos)) //checking if element is present or not using a linear search 
        {
            return true;
        }
        ptrPos = A.next(ptrPos);
    }

    return false;
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : Union
*    Args : 2 lists(sets)
*    Return Type: list(union of 2 sets)
-------------------------------------------------------------------------------------------------*/

List Union(List A, List B) {

    List C; //declaring A new string to store the value
    C.makeNull();   //initialising the new List
    Position endPosA = A.end(), endPosB = B.end(), ptrPos = A.first();    //necessary counter varible

    while(ptrPos!=endPosA)    //adding all of larger elements to new list
    {
        elementType temp = A.retrieve(ptrPos);
        if(!(Search(temp, C)))  //adding elements that are there in A but not repeated.
        {
            C.insert(temp, C.end()); //inserting new elements
        }
        ptrPos = A.next(ptrPos);
    }

    ptrPos = B.first();

    while(ptrPos!=endPosB)    //for loop to traverse accross smaller loop
    {
        elementType temp = B.retrieve(ptrPos);
        if(!(Search(temp, C)))  //adding elements that are there in B but not in A.
        {
            C.insert(temp, C.end()); //inserting new elements
        }
        ptrPos = B.next(ptrPos);
    }

    return C;   //returning new element
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : Intersection
*    Args : 2 lists(sets)
*    Return Type: list(intersection of 2 sets)
-------------------------------------------------------------------------------------------------*/

List Intersection(List A, List B) {

    List C; //declaring A new string to store the value
    C.makeNull();   //initialising the new List
    Position endPosA=A.end(), ptrPos = A.first();    //necessary counter varible

    while(ptrPos != endPosA)   //for loop to travese across the list and checking if these elements are there in other list or not.
    {
        elementType temp = A.retrieve(ptrPos);   //temporary variable to store the retrieved value
        if(Search(temp, B)) //checking if given element is present in the second list  or not
        {
          if(!Search(temp, C))
          {
              C.insert(temp, C.end());    //inserting new element into list C
          }
        }
        ptrPos = A.next(ptrPos);
    }

    return C;   //returning the C intersection of A and B.
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : main
*    Args : None
*    Return Type: int(To Exit)
-------------------------------------------------------------------------------------------------*/

int main() {
  
  List A, B, C;
  int M, N;
  /* Read the input sets and perform union and intersection operations*/
  cin >> M >> N;
  A.makeNull(); B.makeNull();   //initialising my lists
  Position tempPos = C.first();
  
  for(int i=0; i<M; i++)
  {
      elementType array1;
      cin >> array1;  //temporarily storing new input in a variable
      A.insert(array1, A.end()); //using insert function of the list to add new element
  }

  for(int i=0; i<N; i++)
  {
      elementType array2;
      cin >> array2;  //temporarily storing new input in a variable
      B.insert(array2, B.end()); //using insert function of the list to add new element
  }
  
  C = Union(A, B);

  if(C.end()!=1)
  {
    int arrSize = (C.end()-1);
    int* tempPtr = (int*)malloc(arrSize*sizeof(int)); //getting new array to sort elements
    for(int i=0; i<arrSize; i++)
    {
      tempPtr[i] = C.retrieve(tempPos);
      tempPos = C.next(tempPos);
    }

    QuickSort(tempPtr, 0, arrSize-1); //sorting using intro sort
    C.makeNull();

    for(int i=0; i<arrSize; i++)
    {
      C.insert(tempPtr[i], C.end()); //inserting all elements
    }
    C.printList();    //printing the union of sets A and B;
  }

  else
  {
    cout << "$";
  }
  cout << endl; //printing new line 
  tempPos = C.first();
 
  C = Intersection(A, B);
  if(C.end()!=1)
  {
    int arrSize = (C.end()-1);
    int* tempPtr = (int*)malloc(arrSize*sizeof(int)); //getting new array to sort elements
    for(int i=0; i<arrSize; i++)
    {
      tempPtr[i] = C.retrieve(tempPos);
      tempPos = C.next(tempPos);
    }

    QuickSort(tempPtr, 0, arrSize-1); //sorting using intro sort
    C.makeNull();
    
    for(int i=0; i<arrSize; i++)
    {
      C.insert(tempPtr[i], C.end()); //inserting all elements
    }
    C.printList();    //printing the intersection of sets A and B;
  }

  else
  {
    cout << "$";
  }

  return 0; //return value of main
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : QuickPos
*    Args : integer array pointer and 2 integer
*    Return Type: int(Position of the pivot)
-------------------------------------------------------------------------------------------------*/
int QuickPos(int* arr, int low, int high)
{
    int i = low-1;  // a pointer to keep track of number of index of pivoting number
    int key = arr[high];  //value of pivot

    for(int j=low; j<high; j++) //for loop to find the original position of the pivot
    {
        if(arr[j]<key)  //comparing the numbers
        {
            i++;
            if(i!=j)  //swapping only if elems are out of order
            {
                FunSwap(&arr[i], &arr[j]);  //swapping integers
            }
        }
    }

    FunSwap(&arr[i+1], &arr[high]);  //swapping integers
    return i+1; //returning pivot's original index
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : FunSwap
*    Args : adresses of 2 integers
*    Return Type: None
-------------------------------------------------------------------------------------------------*/
void FunSwap(int *x, int *y) //Function for swapping the required 2 values using a temporary variable
{
	int temp = *x;
	*x = *y;
	*y = temp;	
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : QuickSort
*    Args : integer array pointer and 2 integer
*    Return Type: None
-------------------------------------------------------------------------------------------------*/
void QuickSort(int* arr, int start, int end)
{
    if(start < end) //if condition to check array is sorted or not
    {
        int pos = QuickPos(arr, start, end);  //index of the pivot

        QuickSort(arr, start, pos-1); //recurssive function to sort first part of array
        QuickSort(arr, pos+1, end); //recurssive function to sort second part of array
    }
}