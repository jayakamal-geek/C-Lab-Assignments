#include <iostream>
#include <cstdlib>
#include "Heap.h"
using namespace std;

/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : CPP code to manage a MAX-HEAP.
*    Question : Lab09 Q1
-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------
*    Function Name : FunSwap
*    Args : 2 ElementType pointers
*    Return Type: None(swaps 2 ElementTypes)
-------------------------------------------------------------------------------------------------*/
void FunSwap(ElementType *x, ElementType *y) //Function for swapping the required 2 values using a temporary variable
{
	ElementType temp = *x; //temp variable to carry out swapping
	*x = *y;
	*y = temp;	
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : inserHeap
*    Args : ElementType(new element)
*    Return Type: none(inserts new element into heap)
-------------------------------------------------------------------------------------------------*/
void Heap::insertHeap(ElementType x)
{
    last++; //incrimenting last variable
    priority[last] = x; //inserting new element without sorting
    Position tempPos = last;

    if(last!=0) //doing this only if list isnt empty
    {
        while(tempPos) //tempPos doesnt point root keep checking
        {
            Position refNode = (tempPos-1)/2; //getting pointer to parent node

            if(priority[refNode] < priority[tempPos])   //if parent node is less than current node 
            {
                FunSwap(&priority[refNode], &priority[tempPos]);    //swap two vals 
                tempPos = refNode; //updating the value of tempPos
            }

            else
                break; //breaking
        }
    }
}


/*-------------------------------------------------------------------------------------------------
*    Function Name : deleteRoot
*    Args : None
*    Return Type: ElementType(returns deleted Element)
-------------------------------------------------------------------------------------------------*/
ElementType Heap::deleteRoot()
{
    Position tempPos=0, refNode;  //two position checkers to rearrange heap after deletion
    ElementType tempElem = priority[0]; //obtaining root node to return after its deletion
    if(!last) //if only one element exists
    {
        last = -1;  //updating last 
        return tempElem; //returning tempElem
    }

    priority[tempPos] = priority[last]; //updating root node with last element.
    last-=1;
    while(2*tempPos < last) //while loop to rearrange heap
    {
        refNode = 2*tempPos +1; //getting child node position
        if(refNode==last)   //if we approach the last element of the heap
        {
            if(priority[tempPos]<priority[refNode]) //comparing elements to check if need to be exchnged or not
            {
                FunSwap(&priority[refNode], &priority[tempPos]); //swapping elements
                tempPos = last; //updating last tempPos position
            }
            break; //breaking the loop
        }

        else
        {
            if(priority[refNode]<priority[refNode+1]) //comparing child nodes to get larger child node
            {
                refNode++;  //updating childnode pointer
            }

            if(priority[tempPos]<priority[refNode]) //comparing elements to check if need to be exchnged or not
            {
                FunSwap(&priority[tempPos], &priority[refNode]); //swapping elements
                tempPos = refNode; //updating last tempPos position
            }

            else
                break; //breaking if no changes are there
        }
    }
    return tempElem;
}


/*-------------------------------------------------------------------------------------------------
*    Function Name : empty
*    Args : None
*    Return Type: int(1 if heap is empty)
-------------------------------------------------------------------------------------------------*/
int Heap::empty()
{
    if(last==-1)
        return 1;

    return 0;
}


/*-------------------------------------------------------------------------------------------------
*    Function Name : createHeap
*    Args : None
*    Return Type: None(creates empty Heap)
-------------------------------------------------------------------------------------------------*/
void Heap::createHeap()
{
    last = -1;
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : printHeap
*    Args : None
*    Return Type: None(prints the Heap)
-------------------------------------------------------------------------------------------------*/
void Heap::printHeap()
{
    for(int i=0; i<last+1; i++) //for loop to print the heap
    {
        cout << priority[i] << " "; //printing elemnt of the heap followed by space
    }

    if(empty())
    {
        cout << "EMPTY HEAP";
    }

    cout << endl; //printing new line
}
    /***** ADT FUNCTIONS END HERE *****/