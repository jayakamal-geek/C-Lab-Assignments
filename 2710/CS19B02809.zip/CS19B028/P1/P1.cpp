/*  The class Heap defines an ADT Heap. */
/* begin {Definition of class Heap} */
#include <iostream>
#include <cstdlib>
#include "Heap.h"
using namespace std;
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : CPP code to manage a MAX-HEAP.
*    Question : Lab09 Q1
-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------
*    Function Name : main
*    Args : None
*    Return Type: int(for exiting the program)
-------------------------------------------------------------------------------------------------*/
int main()
{
    int heapSize=0; //int variable for heapSize
    ElementType *elemArr, tempElem; //temporary variable for storing input and pointer for sorting
    Heap A; //defining a heap
    A.createHeap(); //creating empty heap

    cin >> heapSize; //taking input for the heap size
    elemArr = (ElementType*)malloc(heapSize*sizeof(ElementType)); //creating 1D array of required size for sorting

    for(int i=0; i<heapSize; i++) //using for loop to take inputs for the heap
    {
        cin >> tempElem; //taking input of new elem
        A.insertHeap(tempElem); //inserting new element into heap
        A.printHeap(); //printing the heap
    }

    for(int i=0; i<heapSize; i++) //for loop for sorting
    {
        elemArr[i] = A.deleteRoot(); //deleting root and storing it in another array.
        cout << elemArr[i] << endl; //printing the deleted root
        A.printHeap(); //printing the heap after deletion
    }

    for(int i=0; i<heapSize; i++) //printing the elements again in decreasing order
    {
        cout << elemArr[i] << " ";
    }

    free(elemArr); //preventing memory leak

    return 0; //return value of main
}