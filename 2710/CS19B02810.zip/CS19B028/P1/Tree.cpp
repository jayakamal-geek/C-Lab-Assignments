#include <iostream>
#include "Tree.h"
using namespace std;

/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : Cpp-code to implement a tree(left child riight siblling notation)
*    Question : Lab10 Q1(odd)
-------------------------------------------------------------------------------------------------*/

void Tree::createNode(int E, Tree leftMostChild, Tree rightSibling) {
   root = new TreeNode;
   root->leftMostChild = leftMostChild.getRoot();
   root->rightSibling = rightSibling.getRoot();
   root->element = E;
}

/*-------------------------------------------------------------------------
 *  getRoot -- Returns the root of a given node
 *    Args:	
 *    Returns:	treeptr
 *    Throws:	
 *    See:	
 *    Bugs:	
 -------------------------------------------------------------------------*/
treeptr Tree::getRoot()
{
  return(root);
}	/*  End of getRoot		End of getRoot   */


/*-------------------------------------------------------------------------
 *  max -- max of two integer variables
 *    Args:int, int	
 *    Returns:	returns the maximum of two numbers
 *    Throws:	
 *    See:	
 *    Bugs:	
 -------------------------------------------------------------------------*/
int Tree::max(int x, int y) {
  if (x > y) 
    return(x);
  else
    return(y);
}


/*-------------------------------------------------------------------------
 *   -- makeTreeHelper a private function
 *    Args:	
 *    Returns: tree
 *    Throws:	
 *    See:	
 *    Bugs:	
 -------------------------------------------------------------------------*/

treeptr Tree::makeTreeHelper(treeptr ptr,int i) {
  if (ptr == NULL) {
    ptr = new TreeNode;
    ptr->element = i;
    ptr->leftMostChild = NULL;
    ptr->rightSibling = NULL;
  }
   else if (i < ptr->element) 
     ptr->leftMostChild = (treeptr) makeTreeHelper(ptr->leftMostChild,i);
   else if (i > ptr->element)
     ptr->rightSibling = (treeptr) makeTreeHelper(ptr->rightSibling,i);
 return(ptr);
}

/*-------------------------------------------------------------------------
 *   -- printTreeHelper a private function recursively prints elements in the tree
 *    Args:	
 *    Returns: tree
 *    Throws:	
 *    See:	
 *    Bugs:	
 -------------------------------------------------------------------------*/


void Tree::printTreeHelper(treeptr ptr,int val) {
  if (ptr != NULL) {
    printTreeHelper(ptr->leftMostChild,0);
    cout << " " << ptr->element << " value " << val << endl ;
    printTreeHelper(ptr->rightSibling,1);
  }
}


/*-------------------------------------------------------------------------
 *  printTree -- public interface function to printTree
 *    Args:	
 *    Returns:	Nothing
 *    Throws:	
 *    See:	
 *    Bugs:	
 -------------------------------------------------------------------------*/
void Tree::printTree() {
  if (root != NULL)
    printTreeHelper(root,0);
  else
    cout << "root is NULL\n";
}

/*-------------------------------------------------------------------------
 *  makeTree -- create a tree with leftMostChild, rightSibling
 *    Args:	
 *    Returns:	makes the tree
 *    Throws:	
 *    See:	
 *    Bugs:	
 -------------------------------------------------------------------------*/


void Tree::makeTree(int *array, int n) {
  int i = 0;
  root = new TreeNode;
  root->leftMostChild = NULL;
  root->rightSibling = NULL;
  root->element = 0;
 
  while (i < n) {
      root->leftMostChild = (treeptr) makeTreeHelper(root->leftMostChild,array[i]);
      i++;
   }
}


/*-------------------------------------------------------------------------
 *  numNodesLevel --  returns the number nodes at a particular level 
 *    Args:	treepointer and 2 integers
 *    Returns:	int
 *    Throws:	
 *    See:	
 *    Bugs:	NIL
 -------------------------------------------------------------------------*/
//Complete This Function
int Tree::numNodesLevel(treeptr ptr, int lev, int curlev) //recurssive function to find number of nodes at a given level.
{
    treeptr tempPtr = ptr->leftMostChild;
    int count=0;

    if(lev==curlev) //if condition to check if desired level is reached or not.
    {
        count++; //incrimenting everytime after finding a anode on the desired level.
    }

    while(tempPtr)  //while loop to enable recurssion by splitting and treating each new node as new root node.
    {
        count = count + numNodesLevel(tempPtr, lev, curlev+1); //calling recurusion at each level and updating value of count.
        tempPtr = tempPtr->rightSibling; //moving to next right node.
    }

    return count; //returning the num count.
}


/*-------------------------------------------------------------------------
 *  height -- returns the height of a tree
 *    Args:	treepointer
 *    Returns:	int
 *    Throws:	
 *    See:	
 *    Bugs:	NIL
 -------------------------------------------------------------------------*/
//Complete This Function
int Tree::height(treeptr ptr) //recurssive function to find number of nodes at a given level.
{
    treeptr tempPtr=ptr->leftMostChild; //temporary pointer to enable recurrsion.
    int count=0, maxVal=0, temp=0; //variables for storing temporary vals anf final value.

    if(tempPtr) //incrimenting height only if another node exists after this node.
    {
        count++; //incrimenting
    }

    while(tempPtr) //while loop to carry sideways recurrsion 
    {
        temp = height(tempPtr); //getting temporary value
        maxVal = max(maxVal, temp); //getting larger value
        tempPtr = tempPtr->rightSibling; //moving to the next pointer.
    }

    count += maxVal; //updating the count value
    return count; //returning the heaight
}

