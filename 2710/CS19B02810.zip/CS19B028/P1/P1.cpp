#include <iostream>
#include "Tree.h"
using namespace std;
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : Cpp-code to implement a tree(left child riight siblling notation)
*    Question : Lab10 Q1(odd)
-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------
 *  main -- Main program
 *    Args:	None
 *    Returns:	int
 *    Throws:	
 *    See:	
 *    Bugs:	
 -------------------------------------------------------------------------*/
int main() {
  int hght,lev;
  Tree T1;
  int i, n;
  int *array;
  cin >> n;
  array = new int [n];
  for (i = 0; i < n; i++)
    cin >> array[i];
  
  T1.makeTree(array, n);
  hght = T1.height(T1.getRoot());
  cout << "Height of the tree is: " << hght << endl;
  
  
  for(lev = 1; lev <= hght+1; lev++)
  {
        cout << "Number of nodes at level " << lev << ": "  << T1.numNodesLevel(T1.getRoot(),lev,1) << endl;
  }
  
  return 0;
}