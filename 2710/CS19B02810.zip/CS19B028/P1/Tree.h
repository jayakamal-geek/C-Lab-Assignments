#pragma once
#include <iostream>
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : Cpp Header-code to implement a tree(left child riight siblling notation)
*    Question : Lab10 Q1(odd)
-------------------------------------------------------------------------------------------------*/

typedef struct tnode* treeptr;
typedef struct tnode {
    int element;
    treeptr leftMostChild;
    treeptr rightSibling;
} TreeNode; 

class Tree {
  private:
    treeptr root;
    void printTreeHelper(treeptr ptr,int val);
    treeptr makeTreeHelper(treeptr ptr,int val);
    int max(int x, int y); 
  public:
     void createNode (int E, Tree L, Tree R);
     void makeTree(int *array, int n);
     treeptr getRoot();
     void printTree();
     
     //Implement the following functions
     int height(treeptr ptr);               
     int numNodesLevel(treeptr ptr, int level, int curlevel);
     
    Tree(){root = NULL;}
    ~Tree () { delete root;}
};