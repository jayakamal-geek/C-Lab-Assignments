#pragma once
#include "Element.h"
#include <iostream>
#include <string>
using namespace std;
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : CPP header file of HashTable to manage a HASH TABLE(with a given hashing function).
*    Question : Lab08 Q1
-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------
*    Class-Name : HashNode.
*    Contents :  1 string and 1 ElemenType.
*    Role : Stores key, Value and ElementType of Value.
-------------------------------------------------------------------------------------------------*/

class HashNode //defining the class HashNode, members of hash function.
{
    public: //public variables of the class.
        string valueString;
        ElementType elemDes; //description of number of vowels and consonants in elements.

        HashNode(string valueString, ElementType elemDes)   //class constructor of the class HashNode
        {
            this->valueString = valueString;    //assigning the string value to instance variable.
            this->elemDes = elemDes;    //assigning the Element type pointer to instance variable to store number of vowels and consonants.
        }
};


class HashTable 
{
    public:
        void MakeHashTable(int);
        void HashTableResize(int);
        void HashTableInsert(string, ElementType); // create your own ElementType that stores number of vowels and consonants.
        ElementType HashTableDelete(string);
        ElementType HashTableFind(string);
        void PrintSizeAndCapacity();
          // add other nessasary member functions.    
        int ComputeKey(string); //function to calculate key of a given string for a given value of arraysize.

    private:
        HashNode** hashTable; //define your own hash node structure or class to store Key, ElementType pair
        int capacity;
        int size;
};