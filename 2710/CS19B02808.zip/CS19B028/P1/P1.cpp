#include <iostream>
#include <string>
#include "Element.h"
#include "HashTable.h"
using namespace std;
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : CPP code to manage a HASH TABLE(with a given hashing function).
*    Question : Lab08 Q1
-------------------------------------------------------------------------------------------------*/

ElementType CheckVowel(string); //this returns an elementtype of the string by counting number of vowels and consonant.

/*-------------------------------------------------------------------------------------------------
*    Function Name : main
*    Args : None
*    Return Type: int(To Exit)
-------------------------------------------------------------------------------------------------*/

int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
    HashTable A;
    int operations, num;    //variables for number of commands and choice of command.
    string name;    //variable for string input.
    cin >> operations;  //taking input for number of commands 
    A.MakeHashTable(2);
    ElementType tempNode;

    for(int i=0; i<operations; i++) //for loop to execute all command one by one.
    {
        cin >> num; //taking input for choice of command.

        switch(num) //switch case to see which command has to be executed.
        {
            case 1:     cin >> name;    //insetion process
                        A.HashTableInsert(name, CheckVowel(name));
                        break;

            case 2:     cin >> name;    //search process
                        tempNode = A.HashTableFind(name);
                        if(!(tempNode.consonants) && !(tempNode.vowels)) //checking if the element exists in the table or not.
                            cout << "Not Found" <<endl;

                        else
                            cout << "Consonants: " << tempNode.consonants << " Vowels: " << tempNode.vowels << endl; //printing number of vowels and consonants.

                        break;

            case 3:     cin >> name;    //deletion
                        tempNode = A.HashTableDelete(name);
                        break;
            
            case 4:     A.PrintSizeAndCapacity(); //printing size and capacity.
                        break;

            default:    cout << "INVALID INPUT" <<endl; //default case to print invalid input.
                        break;
        }
    }

    return 0;   //return value of main.
}

/* below this line are functions that are defined by me*/

/*-------------------------------------------------------------------------------------------------
*    Function Name : CheckVowel
*    Args : string
*    Return Type: ElementType.
-------------------------------------------------------------------------------------------------*/
ElementType CheckVowel(string name)
{
    ElementType tempNode;
    int sizeStr = name.length();     //finding string length

    for(int i=0; i<sizeStr; i++)
    {
        if(name[i]== 97 || name[i]== 101 || name[i]== 105 || name[i]== 111 || name[i]== 117 )
        {
            tempNode.vowels++; //incrimenting number of vowels if any vowels are found.
        }

        else
        {
            tempNode.consonants++; //incrimenting number of consonants.
        }
    }

    return tempNode; //returning element type
}