#pragma once
#include <iostream>
#include <string>
using namespace std;
/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : CPP header file of ElementType to manage a HASH TABLE(with a given hashing function).
*    Question : Lab08 Q1
-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------
*    Struct-Name : ElementType
*    Contents : 2 ints variables.
*    Role : Stores number of vowels and consonants.
-------------------------------------------------------------------------------------------------*/

typedef struct ElementType {  //structure to store number of vowels and consonents.
    int vowels=0; //variable to store number of vowels in the strings.
    int consonants=0; //variable to store number of consonants in the strings.
}NodeElement;