#include <iostream>
#include <string>
#include <cstdlib>
#include "Element.h"
#include "HashTable.h"
using namespace std;

/*-------------------------------------------------------------------------------------------------
*    Author : Maddula Jaya Kamal(cs19b028)
*    Code : CPP code to manage a HASH TABLE(with a given hashing function).
*    Question : Lab08 Q1
-------------------------------------------------------------------------------------------------*/

HashNode* deletedMark = (HashNode*)malloc(sizeof(HashNode)); //A mark to show that this is deleted node.

/*-------------------------------------------------------------------------------------------------
*    Function Name : MakeHashTable
*    Args : int(size of hash table)
*    Return Type: None(creates a hash table of size2)
-------------------------------------------------------------------------------------------------*/
void HashTable::MakeHashTable(int tableSize)
{
    hashTable = (HashNode**)calloc(tableSize, sizeof(HashNode)); //allocating the required size to hashtable.
    //using calloc inorder to initialise all pointers to NULL.
    capacity = tableSize;   //setting the capacity to required table size.
    size = 0;   //size after just creating the hashtable zero.
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : HashTableResize
*    Args : int(size of hash table)
*    Return Type: None(resizes the hashtable)
-------------------------------------------------------------------------------------------------*/
void HashTable::HashTableResize(int sizeNew)
{
    HashNode** hashTableOld = hashTable; //creating a new pointer pointing to the old hashtable.
    int oldCapacity = capacity;
    MakeHashTable(sizeNew); // creating new hashtable.
    HashNode* tempPtr = NULL; //temporary pointer to use for traversal

    for(int i=0; i<oldCapacity; i++)    //for loop to traverse across old hash table and copy the elements into a new table
    {
        tempPtr = hashTableOld[i];

        if(tempPtr!=NULL && tempPtr!=deletedMark)  //doing it only if the pointer is not a null pointer, used while to manage elems with same keys 
        {
            HashTableInsert(tempPtr->valueString, (tempPtr->elemDes));    //inserting the element into new list 
            free(tempPtr);  //freeing the memory allocated to old hash table to prevent memory leaks
        }
    }

    free(hashTableOld); //freeing the memory allocated to old hash table to prevent memory leaks
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : HashTableInsert
*    Args : string and elementtype
*    Return Type: None(inserts a new element into hashtable)
-------------------------------------------------------------------------------------------------*/
void HashTable::HashTableInsert(string value, ElementType description)
{
    int key = ComputeKey(value); //finding the key of the given string.
    ElementType tempNode = HashTableFind(value);

    //finding the first empty space nearest to key(greater than key).
    if(!tempNode.vowels && !tempNode.consonants) //checking if the string is already there in the hash table.
    {
        while(hashTable[key] && hashTable[key]!=deletedMark)
        {
                key++; //incrimenting key to reach nearest empty node
                key%=capacity;
        }

        if(!hashTable[key] || hashTable[key]==deletedMark)
        {
            hashTable[key] = new HashNode(value, description);  //inserting the new element.
            size++; //incrimenting the size
        }
    }

    if(size > (capacity/2)) //resizing the hash table according to the given condition.
    {
        HashTableResize(2*capacity);
    }
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : HashTableInsert
*    Args : string 
*    Return Type: elementtype of deleted hashnode
-------------------------------------------------------------------------------------------------*/
ElementType HashTable::HashTableDelete(string value)
{
    int key = ComputeKey(value); //finding the key of the given string.
    ElementType tempStorage; //returnin variable specifying number of vowels and consonents
    HashNode* delPtr = NULL;  //pointer to free the given chunk of memory

    while(hashTable[key])
    {
        if((hashTable[key]->valueString)==value)    //if the required element is found
            break; //breaking the while loop

        else
        {
            key++;   //incrimenting key to reach required element
            key%=capacity; //open adressing
        }
    }

    if(hashTable[key])
    {
        delPtr = hashTable[key];
        tempStorage = (delPtr->elemDes); //obtaining the return value of the function
        hashTable[key] = deletedMark; //updating the new pointer
        free(delPtr);   //to prevent memory leak
        size--; //decrimenting the size of the hashtable
    }

    if(size < (capacity/4)) //resizing hashtable according to given condition
    {
        HashTableResize(capacity/2);
    }

    return tempStorage; //returning the value that was asked.
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : HashTableInsert
*    Args : string 
*    Return Type: elementtype of input string
-------------------------------------------------------------------------------------------------*/
ElementType HashTable::HashTableFind(string value)
{
    int key = ComputeKey(value); //finding the key of the given string.
    ElementType tempStorage; //returnin variable specifying number of vowels and consonents

    while(hashTable[key]) //while an empty node is not reached
    {
        if((hashTable[key]->valueString)==value)    //if the required element is found
        {
            tempStorage = (hashTable[key]->elemDes);
            break; //breaking the while loop
        }

        else
        {
            key++;   //incrimenting key to reach required element   
            key%=capacity; //open adressing
        }
    }

    return tempStorage; //returning the asked node ptr.
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : PrintSizeAndCapacity
*    Args : None
*    Return Type: none(prints the size and capacity of the hash table)
-------------------------------------------------------------------------------------------------*/
void HashTable::PrintSizeAndCapacity()
{
    cout << "size =" << size << " capacity =" << capacity <<endl; //printing the size and capacity.
}

/*-------------------------------------------------------------------------------------------------
*    Function Name : ComputeKey
*    Args : string and int
*    Return Type: int(key value)
-------------------------------------------------------------------------------------------------*/
int HashTable::ComputeKey(string value)
{
    int strSize = value.length(); //finding string length
    int key = 0;

    /* implementing the given hash function by adding ascci values of chars and getting remainder by dividing with size of hashtable */

    for(int i=0; i<strSize; i++) //for loop to add ascii vals of all chars of the string.
    {
        key = key + value[i];
    }

    key = key%capacity;    //division step

    return key; //returning the key.
}

    /***** ADT FUNCTIONS END HERE *****/